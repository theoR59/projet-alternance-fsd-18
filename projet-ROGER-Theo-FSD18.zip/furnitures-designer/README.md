## Besoin du client

*Présentation générale*

Le client est un designer, il ne se considère pas comme un artiste, mais plutôt comme un artisan. Il dessine les plans de ses meubles, commande les différents matériaux puis les donne à un atelier spécialisé qui les réalise.

Il ne possède pas de magasin pour exposer ses réalisations. 

Il aimerait avoir une application qui liste les meubles qu'il réalise avec la possibilité de voir exactement quels sont les matériaux qu'il a utilisé pour chaque réalisation. Il donne un nom pour chaque meuble qu'il conçoit. Parfois il fait le même meuble plusieurs fois.