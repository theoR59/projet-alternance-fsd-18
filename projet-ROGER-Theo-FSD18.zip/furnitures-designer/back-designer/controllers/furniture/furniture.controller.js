import {
    createFurnitureInDb, createMaterial, findAndDeleteFurniture, findAndDeleteMaterial, findFurniture,
    getAllCategoryFurniture,
    getAllFurnitures,
    getAllRawMaterial, updateFurniture,
} from "../../adapters/furniture/furniture.js";
import {deleteFile, uploadsFiles} from "../../adapters/aws/s3/s3.adapter.js";
import {UpdatingParamsFilesHelper} from "../helpers/UpdatingParamsFiles.helper.js";
import {HandleUploadsFolderHelper} from "../helpers/HandleUploadsFolder.helper.js";


export async function getRawMaterial(req, res) {
    try {
        const allRawMaterial = await getAllRawMaterial()
        res.status(200).json(allRawMaterial)
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function getCategoryFurniture(req, res) {
    try {
        const allCategoryFurniture = await getAllCategoryFurniture()
        res.status(200).json(allCategoryFurniture)
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function getEveryFurnitures(req, res) {
    try {
        const allFurnitures = await getAllFurnitures()
        res.status(200).json(allFurnitures)
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}


export async function createFurniture(req, res) {
    try {
        const furniture = {
            name: req.body.name,
            category: req.body.category,
            material: req.body.materials
        }
        if (furniture.name && furniture.category && furniture.material.length > 0) {
            await createFurnitureInDb(furniture)
            res.status(200).json({message: "Meuble Enregistré !"})
        } else {
            res.status(400).json({message: "Il manque des données pour enregistrer le meuble"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function addNewImage(req, res, next) {
    try {
        let files = req.files
        const furnitureId = req.params._id
        if (files && furnitureId) {
            const furniture = await findFurniture(furnitureId)
            const initialeFilesName = files.map(file => {
                return file.filename
            })
            const updateFilesName = UpdatingParamsFilesHelper.updateFields(files, furniture)
            await uploadsFiles(updateFilesName, furniture).then((response) => {
                res.s3Response = response
                res.furnitureData = furniture
                HandleUploadsFolderHelper.deleteFileInUploadsFolder(initialeFilesName)
                next()
            }).catch((err) => {
                console.log(err)
                HandleUploadsFolderHelper.deleteFileInUploadsFolder(initialeFilesName)
                res.status(400).json({message: "Une erreur à eu lieu"})
            })
        } else {
            res.status(400).json({message: "Aucune image reçu"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function addImageUrlInDb(req, res) {
    try {
        const furniture = res.furnitureData
        const s3Response = res.s3Response
        if (furniture && s3Response) {
            const updatedFurniture = {
                name: furniture.name,
                category: furniture.category,
                material: furniture.material,
                image: {
                    _1200x1200: s3Response[0].Location,
                    _400x400: s3Response[1].Location
                }
            }
            await updateFurniture(furniture._id, updatedFurniture)
            res.status(200).json({message: "Meuble Enregistré !"})
        } else {
            res.status(400).json({message: "Une erreur à eu lieu"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function getDetailFurnitures(req, res) {
    try {
        const furnitureId = req.params._id
        if (furnitureId) {
            const furniture = await findFurniture(furnitureId)
            res.status(200).json(furniture)
        } else {
            res.status(400).json({message: "Une erreur à eu lieu, veuillez recommencer"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function deleteFurniture(req, res) {
    try {
        const furnitureId = req.params._id
        if (furnitureId) {
            const deletedFurniture = await findAndDeleteFurniture(furnitureId)
            if (deletedFurniture.image._1200x1200) {
                await deleteFile(deletedFurniture)
            }
            res.status(200).json({message: "Supprimé"})
        } else {
            res.status(400).json({message: "Une erreur à eu lieu, veuillez recommencer"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function createRawMaterial(req, res) {
    try {
        const newMaterial = {
            name: req.body.name,
            type: req.body.type,
            company: req.body.company
        }
        if (newMaterial.name && newMaterial.type && newMaterial.company) {
            await createMaterial(newMaterial)
            res.status(200).json({message: "Nouveau matériaux ajouté"})
        } else {
            res.status(400).json({message: "Une erreur à eu lieu, veuillez recommencer"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function deleteRawMaterial(req, res) {
    try {
        const materialId = req.params._id
        if (materialId) {
            await findAndDeleteMaterial(materialId)
            res.status(200).json({message: "Supprimé"})
        } else {
            res.status(400).json({message: "Une erreur à eu lieu, veuillez recommencer"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}