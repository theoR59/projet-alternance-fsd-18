import {createUser, findUserPerEmail} from "../../adapters/authentification/authentification.js";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken"
import fs from "fs";

const RSA_PRIVATE = fs.readFileSync("./rsa/key");
const RSA_PUB = fs.readFileSync("./rsa/key.pub");
const TIME_TOKEN_EXPIRATION = 1000 * 60 * 60 * 24 * 30 // 30 jours

export async function signup(req, res) {
    try {
        const body = {
            email: req.body.email,
            password: req.body.password
        }
        await createUser(body)
        res.status(200).json("Inscription réussi")
    } catch (e) {
        console.log(e)
        res.status(400)
    }
}

export async function login(req, res) {
    try {
        const user = await findUserPerEmail(req.body)
        if (user && bcrypt.compareSync(req.body.password, user.password)) {
            const token = await generateToken(user)
            res.cookie("token", token, {
                httpOnly: true,
                secure: true,
                expires: new Date(Date.now() + TIME_TOKEN_EXPIRATION)
            });
            user.password = ""
            return res.status(200).json(user).send();
        } else {
            res.status(403).json({message: "Mauvais email ou mot de passe"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function logout(req, res) {
    try {
        res.clearCookie("token")
        res.status(200).end();
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function getCurrentUser(req, res) {
    try {
        const token = req.cookies.token;
        if (token) {
            const decodedToken = jwt.verify(token, RSA_PUB);
            if (decodedToken) {
                const user = await findUserPerEmail(decodedToken)
                res.status(200).json(user)
            } else {
                res.status(403).json({message: "Utilisateur pas autorisé"});
            }
        } else {
            res.status(403).json({message: "noToken"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

export async function isAuthorizedUser(req, res, next) {
    const token = req.cookies.token;
    try {
        if (token) {
            const decodedToken = jwt.verify(token, RSA_PUB);
            if (decodedToken) {
                const user = await findUserPerEmail(decodedToken)
                user.role === "admin" ? next() : res.status(403).json({message: "Utilisateur non autorisé"})
            } else {
                res.status(403).json({message: "Utilisateur non autorisé"});
            }
        } else {
            res.status(403).json({message: "noToken"})
        }
    } catch (e) {
        console.log(e)
        res.status(400).json({message: "Une erreur à eu lieu"})
    }
}

async function generateToken(user) {
    return jwt.sign({email: user.email, role: user.role}, RSA_PRIVATE, {
        subject: user.email,
        algorithm: 'RS256',
        expiresIn: 60 * 60 * 24 * 30
    });
}
