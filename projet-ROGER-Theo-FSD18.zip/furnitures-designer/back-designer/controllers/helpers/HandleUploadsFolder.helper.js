import fs from "fs";
export class HandleUploadsFolderHelper {

    static deleteFileInUploadsFolder(filesArray) {
        filesArray.forEach(file => {
            fs.unlinkSync('./uploads/'+file)
        })
    }
}