export class UpdatingParamsFilesHelper {
    static _1200 = "1200x1200"
    static _400 = "400x400"

    /**
     * @param furniture : {_id:string, name:string}
     * @param files : Object[]
     */
    static updateFields(files, furniture) {
        for (let i = 0; i < files.length; i++) {
            (i === 0) ?
                files[i].filename = `${furniture._id}-${this._1200}.${this.getFileExtension(files[i])}` :
                files[i].filename = `${furniture._id}-${this._400}.${this.getFileExtension(files[i])}`
        }
        return files
    }

    static getFileExtension(file) {
        let extArray = file.mimetype.split("/");
        let extension = extArray[extArray.length - 1];
        return extension
    }


}