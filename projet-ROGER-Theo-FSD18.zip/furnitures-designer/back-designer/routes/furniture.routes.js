import {Router} from "express";
import {
    createFurniture,
    getCategoryFurniture,
    getRawMaterial, deleteRawMaterial,
    getDetailFurnitures, getEveryFurnitures, deleteFurniture, createRawMaterial, addNewImage, addImageUrlInDb
} from "../controllers/furniture/furniture.controller.js";
import {isAuthorizedUser} from "../controllers/authentification/authentification.controller.js";
import multer from "multer";

const upload = multer({dest: 'uploads'})
const router = Router();

router.all("*", isAuthorizedUser)
router.get("/raw-material", getRawMaterial)
router.get("/category-furniture", getCategoryFurniture)
router.get("/all-furnitures", getEveryFurnitures)
router.get("/:_id", getDetailFurnitures)
router.post("/create", createFurniture)
router.delete("/delete/:_id", deleteFurniture)
router.post("/create-raw-material", createRawMaterial)
router.delete("/delete-raw-material/:_id", deleteRawMaterial)
router.post("/new-image/:_id", upload.array("images"), addNewImage, addImageUrlInDb)

export default router;