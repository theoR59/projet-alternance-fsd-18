import { Router } from "express";

import {getCurrentUser, login, logout, signup} from "../controllers/authentification/authentification.controller.js";

const router = Router();

router.post("/signup", signup)
router.post("/login",login)
router.delete("/logout", logout)
router.get("/current",getCurrentUser)

export default router;