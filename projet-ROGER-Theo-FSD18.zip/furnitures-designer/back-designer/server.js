import express from "express";
import cookieParser from "cookie-parser"
import bodyParser from "body-parser";
import morgan from "morgan";
import dotenv from "dotenv";
import mongoose from "mongoose";
import cors from "cors"
import router from "./routes/index.js";


dotenv.config()


mongoose.connect(`mongodb+srv://${process.env.DB_NAME}:${process.env.DB_PASSWORD}@cluster0.kgtti.mongodb.net/${process.env.DB_TARGET}?retryWrites=true&w=majority`).then(() => {
    console.log(`Connect to database : ${process.env.DB_TARGET}`)
})
const app = express()
const PORT = 3000
const whitelist = ['http://localhost:4200'];
const corsOptions = {
    credentials: true,
    origin: (origin, callback) => {
        if (whitelist.includes(origin))
            return callback(null, true)
        callback(new Error('Not allowed by CORS'));
    }
}
app.use(cors(corsOptions));
app.use(cookieParser())
app.use(morgan("short"))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: false}));
app.disable('x-powered-by');
app.use(router)

app.listen(PORT, () => {
    console.log(`App listening at http://localhost:${PORT}`);
});

