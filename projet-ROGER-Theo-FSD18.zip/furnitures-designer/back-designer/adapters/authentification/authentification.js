import bcrypt from "bcrypt";
import {User} from "../models/user.model.js";

/**
 *
 * @param user :{email:string,password:string}
 * @returns {Promise<*>}
 */
export const createUser = async (user) => {
    try {
        const newUser = new User({
            email: user.email,
            password: bcrypt.hashSync(user.password, bcrypt.genSaltSync(10)),
            role:"Admin"
        });
        return newUser.save();
    } catch (e) {
        throw e;
    }
};
/**
 *
 * @param user :{email:string,password:string}
 * @returns {Promise<{_id:ObjectId,email:string,password:string,role:string}>}
 */
export const findUserPerEmail = (user) => {
    return User.findOne({email: user.email}).exec();
};
