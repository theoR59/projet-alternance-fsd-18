import dotenv from "dotenv";
import fs from "fs";
import pkg from 'aws-sdk';

const {S3} = pkg;
dotenv.config()

const bucketName = process.env.AWS_BUCKET_NAME
const region = process.env.AWS_BUCKET_REGION
const accessKeyId = process.env.AWS_ACCESS_KEY
const secretAccessKey = process.env.AWS_SECRET_KEY

const s3 = new S3({
    region,
    accessKeyId,
    secretAccessKey
})

/**
 *
 * @param file :Object[]
 * @param furniture :Object
 * @returns {Promise<ManagedUpload.SendData>}
 */
function uploadFile(files, furniture) {
    const fileStream = fs.createReadStream(files.path)
    const uploadParams = {
        Bucket: bucketName,
        Body: fileStream,
        Key: `furnituresImage/${furniture._id}/${files.filename}`
    }
    return s3.upload(uploadParams).promise()
}

export async function uploadsFiles(files, furniture) {
    let promise1200 = await uploadFile(files[0], furniture)
    let promise400 = await uploadFile(files[1], furniture)
    return Promise.all([promise1200, promise400])

}

export async function deleteFile(furniture) {

    let params = {
        Bucket: bucketName,
        Prefix: `furnituresImage/${furniture._id}`
    }
    const listedObjects = await s3.listObjectsV2(params).promise();
    if (listedObjects.Contents.length === 0) return;
    const deleteParams = {
        Bucket: bucketName,
        Delete: { Objects: [] }
    };

    listedObjects.Contents.forEach(({ Key }) => {
        deleteParams.Delete.Objects.push({ Key });
    });

    await s3.deleteObjects(deleteParams).promise();

    if (listedObjects.IsTruncated) await deleteFile(furniture);
}