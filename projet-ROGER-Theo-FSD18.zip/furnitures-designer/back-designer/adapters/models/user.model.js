import mongoose from "mongoose";

const Schema = mongoose.Schema;

const UserSchema = new Schema({
    email: {type: String, index: true, unique: true, required: true},
    password: {type: String, required: true},
    role:{type:String}
});

export const User = mongoose.model("user", UserSchema);
