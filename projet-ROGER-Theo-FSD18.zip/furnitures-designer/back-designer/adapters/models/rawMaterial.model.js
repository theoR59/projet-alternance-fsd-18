import mongoose from "mongoose";

const Schema = mongoose.Schema;

const RawMaterialSchema = new Schema({
    name: {type: String,  required: true},
    company: {type: String, required: true},
    type:{type: String, required: true}
})

export const raw_material = mongoose.model("raw_material", RawMaterialSchema);

