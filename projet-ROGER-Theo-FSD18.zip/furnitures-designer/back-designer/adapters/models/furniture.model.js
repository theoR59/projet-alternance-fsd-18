import mongoose from "mongoose";

const Schema = mongoose.Schema;

const FurnitureSchema = new Schema({
    name: {type: String, index: true, required: true},
    category: {type: mongoose.Types.ObjectId, ref: 'categoryFurniture'},
    material: [{type: mongoose.Types.ObjectId, ref: 'raw_material'}],
    image: {
        _1200x1200 :{type: String},
        _400x400:{type: String}
    }
})

export const Furniture = mongoose.model("furniture", FurnitureSchema);

