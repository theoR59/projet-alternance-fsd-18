import mongoose from "mongoose";

const Schema = mongoose.Schema;

const CategoryFurnitureSchema = new Schema({
    name: {type: String, index: true, unique: true, required: true},
})

export const categoryFurniture = mongoose.model("categoryFurniture", CategoryFurnitureSchema);

