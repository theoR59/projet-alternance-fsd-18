import {raw_material} from "../models/rawMaterial.model.js";
import {categoryFurniture} from "../models/categoryFurniture.model.js";
import {Furniture} from "../models/furniture.model.js";
import bcrypt from "bcrypt";
import mongoose from "mongoose";


export const getAllRawMaterial = () => {
    return raw_material.find().exec()
}

export const getAllCategoryFurniture = () => {
    return categoryFurniture.find().exec()
}

export const getAllFurnitures = () => {
    return Furniture.find().populate({path: 'category', select: "-__v"}).populate({
        path: 'material',
        select: "-__v"
    }).exec()
}


/**
 *
 * @param furniture :{name:string,category:string,material:string[]}
 * @returns {Promise<*>}
 */
export const createFurnitureInDb = async (furniture) => {
    try {
        const newFurniture = new Furniture({
            name: furniture.name,
            category: furniture.category,
            material: furniture.material,
            image : {
                _1200x1200 :"",
                _400x400:""
            }
        });
        return newFurniture.save();
    } catch (e) {
        throw e;
    }
};

export const createMaterial = async (material)=>{
    try{
        const newMaterial = new raw_material({
            name: material.name,
            type: material.type.toLowerCase(),
            company: material.company
        })
        return newMaterial.save()
    } catch (e) {
        throw e;
    }
}

export const findFurniture = async (furnitureId) => {
    return Furniture.findById(furnitureId).populate({path: 'category', select: "-__v"}).populate({
        path: 'material',
        select: "-__v"
    }).exec()
}

export const updateFurniture = async (id,furniture)=>{
    return Furniture.findOneAndUpdate({_id : id}, {$set:furniture})
}

export const findAndDeleteFurniture = async (furnitureId) => {
    return Furniture.findByIdAndDelete(furnitureId).exec()
}
export const findAndDeleteMaterial = async (materialId) => {
    return raw_material.findByIdAndDelete(materialId).exec()
}