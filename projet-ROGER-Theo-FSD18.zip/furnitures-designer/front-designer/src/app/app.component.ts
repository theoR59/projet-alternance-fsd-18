import { Component } from '@angular/core';
import {LayoutService} from "../modules/layout/services/layout.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  constructor(private layoutServices: LayoutService) {
  }

  public isSideBarShow():boolean{
    return this.layoutServices.canShowSidebar.value
  }
}
