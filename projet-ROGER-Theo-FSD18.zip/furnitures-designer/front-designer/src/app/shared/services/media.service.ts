import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../environments/environment";
import {DOC_ORIENTATION, NgxImageCompressService} from "ngx-image-compress";
import {forkJoin, from, mergeMap, Observable, ObservedValueOf, of, switchMap, tap} from "rxjs";
import {NgxUiLoaderService} from "ngx-ui-loader";

@Injectable({
  providedIn: 'root'
})
export class MediaService {
  private readonly compressParams = {
    RATIO: 75,
    QUALITY: 75,
    MAX_WIDTH_1200: 1200,
    MAX_WIDTH_400: 400
  }

  constructor(private http: HttpClient, private imageCompress: NgxImageCompressService, private ngxLoader: NgxUiLoaderService) {
  }

  public uploadImage(file: File, furnitureId: string) {
    return this.convertFileToBase64(file).pipe(
      switchMap((base64) => {
        return this.getAllCompressedImage(base64)
      }),
      mergeMap((images) => {
        return this.transformAllBase64ToFile(images, file)
      }),
      switchMap((image) => {
        return this.uploadToS3(image, furnitureId)
      })
    )
  }

  private convertFileToBase64(file: File): Observable<string> {
    return from(new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        resolve((<FileReader>event.target).result as string);
      }
      reader.onerror = (event) => {
        reject(event);
      }
    }));
  }

  private mapImageToFormData(image: { _1200x1200: File, _400x400: File }): Object {
    const fd = new FormData()
    for (let i = 0; i < 2; i++) {
      i === 0 ?
        fd.append("images", image._1200x1200, image._1200x1200.name) :
        fd.append("images", image._400x400, image._400x400.name)
    }
    return fd
  }

  private compressImage(image: string, size: number): Observable<ObservedValueOf<Promise<string>>> {
    return from(this.imageCompress.compressFile(image, DOC_ORIENTATION.Default, this.compressParams.RATIO, this.compressParams.QUALITY, size)
      .then(result => {
        return result
      }))
  }

  private getAllCompressedImage(base64: string) {
    return forkJoin({
        _1200x1200: this.compressImage(base64, this.compressParams.MAX_WIDTH_1200),
        _400x400: this.compressImage(base64, this.compressParams.MAX_WIDTH_400),
      }
    )
  }

  private uploadToS3(images: { _1200x1200: File, _400x400: File }, furnitureId: string) {
    this.ngxLoader.start()
    return this.http.post(`${environment.URL_BACK}${environment.URL_BACK_UPDATE_IMAGE}/${furnitureId}`, this.mapImageToFormData(images), {withCredentials: true})
      .pipe(
        tap(() => {
          this.ngxLoader.stop()
        })
      )
  }

  private transformAllBase64ToFile(images: { _1200x1200: string, _400x400: string }, file: File) {
    return forkJoin({
        _1200x1200: this.base64ToFile(images._1200x1200, file.name),
        _400x400: this.base64ToFile(images._400x400, file.name)
      }
    )
  }

  private base64ToFile(dateUrl: string, filename: string) {
    let arr = dateUrl.split(','),
      mime = arr[0].match(/:(.*?);/)![1],
      bstr = atob(arr[1]),
      n = bstr.length,
      u8arr = new Uint8Array(n);
    while (n--) {
      u8arr[n] = bstr.charCodeAt(n);
    }
    return of(new File([u8arr], filename, {type: mime}))
  }
}
