import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path:"dashboard",
    loadChildren: () => import("../modules/furnitures/furnitures.module").then(m =>m.FurnituresModule )
  },
  {
    path: "auth",
    loadChildren: () => import("../modules/authentification/authentification.module").then(m => m.AuthentificationModule)
  },
  {path: "**", redirectTo: "dashboard"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
