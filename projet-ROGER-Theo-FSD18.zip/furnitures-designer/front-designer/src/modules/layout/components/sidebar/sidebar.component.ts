import {Component, OnDestroy, OnInit} from '@angular/core';
import {AuthentificationService} from "../../../authentification/services/authentification.service";
import {LayoutService} from "../../services/layout.service";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit, OnDestroy {
  public userEmail: string = ""

  private subscribeOnUser?: Subscription

  constructor(private authServices: AuthentificationService, private layoutService: LayoutService) {
  }

  ngOnInit(): void {
    this.subscriptionOnUser()
  }

  ngOnDestroy() {
    this.subscribeOnUser?.unsubscribe()
  }

  private subscriptionOnUser() {
    this.subscribeOnUser = this.authServices.user.subscribe({
      next: (user) => {
        this.userEmail = user.email
      }
    })
  }

  public canShowSidebar(): boolean {
    return this.layoutService.canShowSidebar.value
  }

  public toggleSideBar(): void {
    this.layoutService.canShowSidebar.next(!this.layoutService.canShowSidebar.value)
  }
}
