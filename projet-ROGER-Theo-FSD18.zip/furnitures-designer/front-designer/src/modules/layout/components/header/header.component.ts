import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {UserBean} from "../../../authentification/beans/user.bean";
import {AuthentificationService} from "../../../authentification/services/authentification.service";
import {Router} from "@angular/router";
import {LayoutService} from "../../services/layout.service";
import {FurnituresBean} from "../../../furnitures/beans/Furnitures.bean";
import {FurnituresService} from "../../../furnitures/services/furnitures.service";
import {environment} from "../../../../environments/environment";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {

  public canShowMenu: boolean = false
  public user: UserBean = new UserBean()
  public searchBarForm!: FormGroup
  public searchBarResult: FurnituresBean[] = []
  public showNoResultMessage: boolean = false
  public searchBarShow: boolean = false
  public p: number = 1;
  private subscribeOnUser?: Subscription



  constructor(private formBuilder: FormBuilder, private furnitureService: FurnituresService, private router: Router, private authentification: AuthentificationService, private layoutServices: LayoutService) {
  }

  ngOnInit(): void {
    this.subscriptionOnUser()
    this.searchBarForm = this.formBuilder.group({
      bar: ["", Validators.required]
    })
  }

  ngOnDestroy() {
    this.subscribeOnUser?.unsubscribe()
  }

  private subscriptionOnUser() {
    this.subscribeOnUser = this.authentification.user.subscribe({
      next: (user) => {
        this.user = user
      }
    })
  }

  public toggleSidebar() {
    this.layoutServices.canShowSidebar.next(!this.layoutServices.canShowSidebar.value)
  }

  public toggleMenuHeader() {
    this.canShowMenu = !this.canShowMenu
  }

  public logout() {
    this.authentification.logout().subscribe()
  }

  public submitForm() {
    this.searchBarShow = true
    this.searchBarResult = []
    if (this.searchBarForm.valid && this.searchBarForm.get("bar")?.value.length > 1) {
      const searchValue: string = this.searchBarForm.getRawValue().bar.toLowerCase()
      this.furnitureService.getAllFurnitures().subscribe(
        (list: FurnituresBean[]) => {
          this.searchBarResult = list.filter(item => {
            return (
              item.name.toLowerCase().includes(searchValue) ||
              item.category.name.toLowerCase().includes(searchValue)
            )
          })
          this.showNoResultMessage = (this.searchBarResult.length === 0)
        }
      )
    } else {
      this.showNoResultMessage = true
    }
    this.hideSearchBar()
  }

  public redireToFurnitureDetails(furniture: FurnituresBean): void {
    this.searchBarShow = false
    this.layoutServices.canShowSidebar.next(false)
    this.router.navigateByUrl(environment.URL_FRONT_FURNITURE_DETAIL + furniture.id)
  }

  private hideSearchBar(): void {
    this.router.events.subscribe((event) => {
      if (event) {
        this.searchBarShow = false
      }
    })
  }
}
