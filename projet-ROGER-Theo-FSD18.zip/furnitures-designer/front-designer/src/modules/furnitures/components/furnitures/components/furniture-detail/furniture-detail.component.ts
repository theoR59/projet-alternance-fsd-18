import { Component, OnInit } from '@angular/core';
import {ImageSnippet} from "../../../../../../app/shared/beans/ImageSnippet";
import {FormBuilder, FormGroup} from "@angular/forms";
import {ActivatedRoute, Router} from "@angular/router";
import {FurnituresBean} from "../../../../beans/Furnitures.bean";
import {MediaService} from "../../../../../../app/shared/services/media.service";
import {FurnituresService} from "../../../../services/furnitures.service";
import {RawMaterialsBean} from "../../../../beans/RawMaterials.bean";
import {environment} from "../../../../../../environments/environment";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-furniture-detail',
  templateUrl: './furniture-detail.component.html',
  styleUrls: ['./furniture-detail.component.css']
})
export class FurnitureDetailComponent implements OnInit {
  public furniture: FurnituresBean = new FurnituresBean()
  public canShowModal: boolean = false
  public arrayOfCompanyName: string[] = []
  public showModalForm: boolean = false
  public selectedFile: ImageSnippet | undefined;
  public imageForm!: FormGroup
  private furnitureId : string = ""

  constructor(
    private router: Router, private activatedRoute: ActivatedRoute, private furnitureService: FurnituresService, private mediaService: MediaService,
    private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.getDetail()
    this.initForm()
  }


  public getDetail(): void {
    this.activatedRoute.params.subscribe(
      (param: any) => {
        this.furnitureId = param.id
        this.furnitureService.getFurniture(this.furnitureId).subscribe(
          (furniture: FurnituresBean) => {
            this.furniture = furniture
            this.arrayOfCompanyName = this.getArrayOfUniqueName(furniture)
          }
        )
      }
    )
  }

  public toggleModale() {
    this.canShowModal = !this.canShowModal
  }

  public toggleModaleFormImage() {
    this.showModalForm = !this.showModalForm
  }

  public delete(furniture: FurnituresBean) {
    this.furnitureService.deleteFurniture(furniture).subscribe(
      () => {
        this.router.navigateByUrl(environment.URL_FRONT_FURNITURE_LIST)
      }
    )
  }

  private getArrayOfUniqueName(furniture: FurnituresBean): string[] {
    const initialArray: RawMaterialsBean[] = furniture.material
    const sortedArrayOfUniqueName: string[] = []
    initialArray.forEach((material: RawMaterialsBean) => {
      if (!sortedArrayOfUniqueName.includes(material.company)) {
        sortedArrayOfUniqueName.push(material.company)
      }
    })

    return sortedArrayOfUniqueName
  }

  public fileChosen(imageInput: any) {
    if (imageInput.target.value) {
      const file = <File>imageInput.target.files[0]
      const reader = new FileReader()
      reader.addEventListener('load', (event: any) => {
        this.selectedFile = new ImageSnippet(event.target.result, file);
      });
      reader.readAsDataURL(file)
    }
  }

  public sendImage() {
    if (this.selectedFile?.file) {
      this.mediaService.uploadImage(this.selectedFile!.file, this.furnitureId).subscribe(()=>{
        this.router.navigateByUrl(environment.URL_FRONT_FURNITURE_LIST)
      })
      this.toggleModaleFormImage()
    }
  }

  private initForm() {
    this.imageForm = this.fb.group({
      image: ""
    })
  }
}
