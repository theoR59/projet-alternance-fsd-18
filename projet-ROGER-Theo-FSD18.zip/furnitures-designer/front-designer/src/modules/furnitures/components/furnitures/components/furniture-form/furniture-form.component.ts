import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormArray, FormBuilder, FormControl, FormGroup, Validators} from "@angular/forms";
import {CategoryFurnituresBean} from "../../../../beans/CategoryFurnitures.bean";
import {MediaService} from "../../../../../../app/shared/services/media.service";
import {Router} from "@angular/router";
import {RawMaterialsBean} from "../../../../beans/RawMaterials.bean";
import {FurnituresService} from "../../../../services/furnitures.service";
import {environment} from "../../../../../../environments/environment";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-furniture-form',
  templateUrl: './furniture-form.component.html',
  styleUrls: ['./furniture-form.component.css']
})
export class FurnitureFormComponent implements OnInit, OnDestroy {


  public furnitureForm!: FormGroup
  public listCategories: CategoryFurnituresBean[] = []
  public listMaterial: RawMaterialsBean[] = []
  public showErrorMessage: boolean = false
  public showErrorMessageHttp: boolean = false
  private subscriptionOnCategory? : Subscription
  private subscriptionOnRawMaterials? : Subscription

  constructor(private mediaService : MediaService,private formBuilder: FormBuilder, private router: Router, private furnitureService: FurnituresService) {
  }

  ngOnInit(): void {
    this.subscribeOnCategory()
    this.subscribeOnRawMaterials()
    this.getAllDataForTheForm()
    this.furnitureForm = this.formBuilder.group({
      name: ["", Validators.required],
      category: ["", Validators.required],
      materials: new FormArray([], Validators.required),
      image: [""]
    })
  }
  ngOnDestroy() {
    this.subscriptionOnCategory?.unsubscribe()
    this.subscriptionOnRawMaterials?.unsubscribe()

  }

  private subscribeOnCategory():void{
    this.subscriptionOnCategory = this.furnitureService.listCategories.subscribe({
      next:(category)=>{
        this.listCategories = category
      }
    })
  }

  private subscribeOnRawMaterials():void{
    this.subscriptionOnRawMaterials = this.furnitureService.listRawMaterials.subscribe({
      next:(listFurnitures)=>{
        this.listMaterial = listFurnitures
      }
    })
  }

  public submitFurniture() {
    this.showErrorMessage = false
    this.showErrorMessageHttp = false
    if (this.furnitureForm.valid) {
      this.furnitureService.createFurniture(this.furnitureForm.getRawValue()).subscribe(
        () => {
          this.router.navigateByUrl(environment.URL_FRONT_DASHBOARD)
        }, () => {
          this.showErrorMessage = true
        }
      )
    } else {
      this.showErrorMessage = true
    }
  }



  private getAllDataForTheForm() {
    this.furnitureService.getAllCategories().subscribe(
      (list: CategoryFurnituresBean[]) => {
        this.listCategories = list
      }
    )
    this.furnitureService.getAllRawMaterial().subscribe(
      (list: RawMaterialsBean[]) => {
        this.listMaterial = list
      }
    )
  }

  public onCheckboxChange(event: any) {
    const selectedCountries = (this.furnitureForm.controls['materials'] as FormArray);
    if (event.target.checked) {
      selectedCountries.push(new FormControl(event.target.value));
    } else {
      const index = selectedCountries.controls
        .findIndex(x => x.value === event.target.value);
      selectedCountries.removeAt(index);
    }
  }
}
