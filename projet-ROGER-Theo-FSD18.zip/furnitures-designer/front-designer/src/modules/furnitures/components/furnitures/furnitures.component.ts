import {Component, OnDestroy, OnInit} from '@angular/core';
import {FurnituresBean} from "../../beans/Furnitures.bean";
import {Router} from "@angular/router";
import {FurnituresService} from "../../services/furnitures.service";
import {environment} from "../../../../environments/environment";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-furnitures',
  templateUrl: './furnitures.component.html',
  styleUrls: ['./furnitures.component.css']
})
export class FurnituresComponent implements OnInit, OnDestroy  {
  public listFurnitures: FurnituresBean[] = []
  public p: number = 1;
  private subscriptionOnListFurnitures? : Subscription

  constructor(private router: Router, private furnitureServices: FurnituresService) {
  }

  ngOnInit(): void {
    this.subscribeOnListFurnitures()
    this.furnitureServices.getAllFurnitures().subscribe()
  }

  ngOnDestroy() {
    this.subscriptionOnListFurnitures?.unsubscribe()
  }

  private subscribeOnListFurnitures():void{
    this.subscriptionOnListFurnitures = this.furnitureServices.listFurnitures.subscribe({
      next:(listFurnitures)=>{
        this.listFurnitures = listFurnitures
      }
    })
  }

  public redireToFurnitureDetails(furniture: FurnituresBean): void {
    this.router.navigateByUrl(environment.URL_FRONT_FURNITURE_DETAIL + furniture.id)
  }

}
