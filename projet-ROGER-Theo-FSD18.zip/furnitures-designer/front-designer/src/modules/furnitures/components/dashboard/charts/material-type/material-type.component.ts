import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {BarController, BarElement, CategoryScale, Chart, Legend, LinearScale} from "chart.js";
import {RawMaterialsBean} from "../../../../beans/RawMaterials.bean";
import {FurnituresService} from "../../../../services/furnitures.service";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-material-type',
  templateUrl: './material-type.component.html',
  styleUrls: ['./material-type.component.css']
})
export class MaterialTypeComponent implements OnInit, OnDestroy {
  public materialsList: RawMaterialsBean[] = []
  public chart: Chart | null = null
  @ViewChild('canvas') el!: ElementRef<HTMLCanvasElement>;
  private subscriptionOnRawMaterials? : Subscription

  constructor(private furnitureService: FurnituresService) {
  }

  ngOnInit(): void {
    this.subscribeOnRawMaterials()
  }

  private subscribeOnRawMaterials():void{
    this.subscriptionOnRawMaterials = this.furnitureService.listRawMaterials.subscribe({
      next:(listFurnitures)=>{
        this.materialsList = listFurnitures
        if (this.el) {
          this.createCanvas(this.el.nativeElement)
        }
      }
    })
  }

  private createCanvas(element: HTMLCanvasElement) {
    Chart.register(Legend, BarElement, BarController, CategoryScale, LinearScale)
    const ctx: HTMLCanvasElement = element
    this.chart = new Chart(ctx, {
      type: "bar",
      data: {
        labels: this.getArrayOfName(this.materialsList),
        datasets: [{
          data: this.getCountOfType(this.materialsList),
          backgroundColor: this.generateColorForEachItem(this.getArrayOfName(this.materialsList))
        }]
      },
      options: {
        plugins: {
          legend: {
            display: false
          }
        }
      }
    })
  }

  private getArrayOfName(array: RawMaterialsBean[]): string[] {
    const arrayOfType: string[] = []
    array.forEach((material: RawMaterialsBean) => {
      if (!arrayOfType.includes(material.type)) {
        arrayOfType.push(material.type)
      }
    })
    return arrayOfType
  }

  private getCountOfType(array: RawMaterialsBean[]): number[] {
    const arrayOfUniqueName: string[] = this.getArrayOfName(array)
    const result: { item: string, count: number }[] = arrayOfUniqueName.map((item: string) => {
      return {item, count: 0}
    })
    array.forEach(material => {
      for (let i = 0; i < result.length; i++) {
        if (material.type === result[i].item) {
          result[i].count += 1
        }
      }
    })
    const arrayOfNumber: number[] = result.map(value => value.count)
    return arrayOfNumber
  }

  private generateColorForEachItem(arrayOfName: string[]): string[] {
    return arrayOfName.map(() => {
      const randomColor = Math.floor(Math.random() * 16777215).toString(16);
      return "#" + randomColor
    })

  }


  ngOnDestroy() {
    this.chart?.destroy()
    this.subscriptionOnRawMaterials?.unsubscribe()
  }
}
