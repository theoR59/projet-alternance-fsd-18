import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormBuilder, FormGroup} from "@angular/forms";
import {FurnituresBean} from "../../../../beans/Furnitures.bean";
import {Router} from "@angular/router";
import {RawMaterialsBean} from "../../../../beans/RawMaterials.bean";
import {FurnituresService} from "../../../../services/furnitures.service";
import {environment} from "../../../../../../environments/environment";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-furniture-table',
  templateUrl: './furniture-table.component.html',
  styleUrls: ['./furniture-table.component.css']
})
export class FurnitureTableComponent implements OnInit,OnDestroy {
  public p: number = 1;
  public furnitureList: FurnituresBean[] = []
  public furnitureListFiltered : FurnituresBean[] = []
  public materialList: RawMaterialsBean[] = []
  public selectedValue: string = ""
  public filterForm!: FormGroup
  private filterMaterial: RawMaterialsBean = new RawMaterialsBean()
  private subscriptionOnListFurnitures? : Subscription
  private subscriptionOnRawMaterials? : Subscription


  constructor(private formBuilder: FormBuilder, private router: Router, private furnitureService: FurnituresService) {
  }

  ngOnInit(): void {
    this.subscribeOnListFurnitures()
    this.subscribeOnRawMaterials()
    this.filterForm = this.formBuilder.group({
      category: "",
      material: ""
    })
  }

  ngOnDestroy() {
    this.subscriptionOnListFurnitures?.unsubscribe()
    this.subscriptionOnRawMaterials?.unsubscribe()
  }

  private subscribeOnListFurnitures():void{
    this.subscriptionOnListFurnitures = this.furnitureService.listFurnitures.subscribe({
      next:(listFurnitures)=>{
        this.furnitureList = listFurnitures
        this.furnitureListFiltered = listFurnitures
      }
    })
  }
  private subscribeOnRawMaterials():void{
    this.subscriptionOnRawMaterials = this.furnitureService.listRawMaterials.subscribe({
      next:(listFurnitures)=>{
        this.materialList = listFurnitures
      }
    })
  }

  public redireToFurnitureDetails(furniture: FurnituresBean): void {
    this.router.navigateByUrl(environment.URL_FRONT_FURNITURE_DETAIL + furniture.id)
  }

  public filterChangeMaterial(e: any) {
    this.filterMaterial = e as RawMaterialsBean
  }

  public filterChange(e: Event) {
    if(!this.filterMaterial){
      this.furnitureListFiltered = this.furnitureList
    }
    if (e && this.filterMaterial.id) {
      this.furnitureListFiltered = this.furnitureList.filter((furniture) => {
        return (this.checkIfMaterialIdIsInFurniture(furniture)) ? furniture : false
      })
    }
  }

  private checkIfMaterialIdIsInFurniture(furniture: FurnituresBean): boolean {
    return furniture.material.filter(mat => mat.id === this.filterMaterial.id).length > 0
  }
}
