import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {ArcElement, Chart, Legend, PieController} from "chart.js";
import {FurnituresBean} from "../../../../beans/Furnitures.bean";
import {FurnituresService} from "../../../../services/furnitures.service";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit, OnDestroy {
  public list: FurnituresBean[] = []
  public chart: Chart | null = null
  @ViewChild('canvasCate') el!: ElementRef<HTMLCanvasElement>;
  private subscriptionOnListFurnitures? : Subscription

  constructor(private furnitureService: FurnituresService) {
  }

  ngOnInit(): void {
    this.subscribeOnListFurnitures()
  }

  private subscribeOnListFurnitures():void{
    this.subscriptionOnListFurnitures = this.furnitureService.listFurnitures.subscribe({
      next:(listFurnitures)=>{
        this.list = listFurnitures
        if (this.el && this.chart === null) {
          this.createCanvas(this.el.nativeElement)
        }
      }
    })
  }

  private createCanvas(element: HTMLCanvasElement) {
    Chart.register(PieController, ArcElement, Legend)
    const ctx: HTMLCanvasElement = element
    this.chart = new Chart(ctx, {
      type: "pie",
      data: {
        labels: this.getArrayOfName(this.list),
        datasets: [{
          data: this.getArrayOfSize(this.list),
          backgroundColor: [
            'rgba(248,29,69,0.53)',
            'rgba(54,162,235,0.44)'
          ],
          borderColor: [
            'rgb(250,0,49)',
            'rgba(54, 162, 235, 1)'
          ],
          borderWidth: 1
        }]
      }, options: {
        plugins: {
          legend: {
            display: true,
            position: 'bottom'
          }
        }
      }
    })
  }

  private getArrayOfName(array: FurnituresBean[]): string[] {
    const arrayOfName: string[] = []
    array.forEach((material: FurnituresBean) => {
      if (!arrayOfName.includes(material.category.name)) {
        arrayOfName.push(material.category.name)
      }
    })
    return arrayOfName
  }

  private getArrayOfSize(array: FurnituresBean[]): number[] {
    const arrayOfUniqueName: string[] = this.getArrayOfName(array)
    const result: { name: string, count: number }[] = arrayOfUniqueName.map((name: string) => {
      return {name, count: 0}
    })
    array.forEach(furniture => {
      for (let i = 0; i < result.length; i++) {
        if (furniture.category.name === result[i].name) {
          result[i].count += 1
        }
      }
    })
    const arrayOfNumber: number[] = result.map(value => value.count)
    return arrayOfNumber
  }

  ngOnDestroy() {
    this.chart?.destroy()
    this.subscriptionOnListFurnitures?.unsubscribe()
  }

}
