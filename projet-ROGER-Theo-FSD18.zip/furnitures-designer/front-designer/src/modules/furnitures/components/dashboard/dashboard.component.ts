import {Component, OnDestroy, OnInit} from '@angular/core';
import {CategoryFurnituresBean} from "../../beans/CategoryFurnitures.bean";
import {FurnituresBean} from "../../beans/Furnitures.bean";
import {FurnituresService} from "../../services/furnitures.service";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit, OnDestroy {

  public listFurnitures: FurnituresBean[] = []
  public categoryFilterList: CategoryFurnituresBean[] = []

  private subscriptionOnListFurnitures? : Subscription
  private subscriptionOnCategory? : Subscription



  constructor(private furnitureService: FurnituresService) {
  }

  ngOnInit(): void {
    this.subscribeOnListFurnitures()
    this.subscribeOnCategory()
    this.furnitureService.getAllFurnitures().subscribe()
    this.furnitureService.getAllRawMaterial().subscribe()
    this.furnitureService.getAllCategories().subscribe()
  }

  ngOnDestroy() {
    this.subscriptionOnListFurnitures?.unsubscribe()
    this.subscriptionOnCategory?.unsubscribe()
  }

  private subscribeOnListFurnitures():void{
    this.subscriptionOnListFurnitures = this.furnitureService.listFurnitures.subscribe({
      next:(listFurnitures)=>{
        this.listFurnitures = listFurnitures
      }
    })
  }

  private subscribeOnCategory():void{
    this.subscriptionOnCategory = this.furnitureService.listCategories.subscribe({
      next:(category)=>{
        this.categoryFilterList = category
      }
    })
  }

  public sortListByCategory(category: string) {
    this.listFurnitures = this.listFurnitures.filter((furniture) => {
      return (furniture.category.name === category)
    })
  }
}
