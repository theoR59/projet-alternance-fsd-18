import { Component, OnInit } from '@angular/core';
import {FurnituresService} from "../../services/furnitures.service";

@Component({
  selector: 'app-material',
  templateUrl: './material.component.html',
  styleUrls: ['./material.component.css']
})
export class MaterialComponent implements OnInit {

  constructor(private furnitureService : FurnituresService) { }

  ngOnInit(): void {
    this.furnitureService.getAllRawMaterial().subscribe()
  }

}
