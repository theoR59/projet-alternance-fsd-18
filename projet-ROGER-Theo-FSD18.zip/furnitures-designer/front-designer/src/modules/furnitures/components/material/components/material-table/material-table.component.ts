import {Component, OnDestroy, OnInit} from '@angular/core';
import {RawMaterialsBean} from "../../../../beans/RawMaterials.bean";
import {FurnituresService} from "../../../../services/furnitures.service";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-material-table',
  templateUrl: './material-table.component.html',
  styleUrls: ['./material-table.component.css']
})
export class MaterialTableComponent implements OnInit,OnDestroy {
  p: number = 1;
  public listMaterials : RawMaterialsBean[] = []
  constructor(private furnitureService: FurnituresService) { }
  private subscriptionOnRawMaterials? : Subscription

  ngOnInit(): void {
    this.subscribeOnRawMaterials()

  }

  public deleteMaterial(material:RawMaterialsBean):void{
    this.furnitureService.deleteMaterial(material).subscribe(
      ()=>{
        this.furnitureService.getAllRawMaterial().subscribe()
      }
    )
  }

  ngOnDestroy() {
    this.subscriptionOnRawMaterials?.unsubscribe()
  }

  private subscribeOnRawMaterials():void{
    this.subscriptionOnRawMaterials = this.furnitureService.listRawMaterials.subscribe({
      next:(listFurnitures)=>{
        this.listMaterials = listFurnitures
      }
    })
  }
}
