import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import {FurnituresService} from "../../../../services/furnitures.service";
import {environment} from "../../../../../../environments/environment";

@Component({
  selector: 'app-material-form',
  templateUrl: './material-form.component.html',
  styleUrls: ['./material-form.component.css']
})
export class MaterialFormComponent implements OnInit {
  public showErrorMessage: boolean = false
  public showErrorMessageHttp: boolean = false
  public form!: FormGroup

  constructor(private router: Router, private formBuilder: FormBuilder, private furnitureService: FurnituresService) {
  }

  ngOnInit(): void {
    this.initForm()
  }

  private initForm() {
    this.form = this.formBuilder.group({
      name: ["", Validators.required],
      type: ["", Validators.required],
      company: ["", Validators.required]
    })
  }

  public submitForm() {
    this.showErrorMessage = false
    this.showErrorMessageHttp = false
    if (this.form.valid) {
      this.furnitureService.createMaterial(this.form.getRawValue()).subscribe(
        ()=>{
          this.router.navigateByUrl(environment.URL_FRONT_MATERIAL_LIST)
        } , ()=>{
          this.showErrorMessageHttp = true
        }
      )
    } else {
      this.showErrorMessage = true
    }
  }
}
