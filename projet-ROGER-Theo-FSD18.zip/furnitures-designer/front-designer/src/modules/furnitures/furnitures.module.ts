import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { CategoryComponent } from './components/dashboard/charts/category/category.component';
import { MaterialTypeComponent } from './components/dashboard/charts/material-type/material-type.component';
import { FurnitureTableComponent } from './components/dashboard/components/furniture-table/furniture-table.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {NgxPaginationModule} from "ngx-pagination";
import {FURNITURES_ROUTES} from "./furnitures.routing";
import {RouterModule} from "@angular/router";
import { MaterialComponent } from './components/material/material.component';
import { MaterialFormComponent } from './components/material/components/material-form/material-form.component';
import { MaterialTableComponent } from './components/material/components/material-table/material-table.component';
import { FurnituresComponent } from './components/furnitures/furnitures.component';
import { FurnitureDetailComponent } from './components/furnitures/components/furniture-detail/furniture-detail.component';
import { FurnitureFormComponent } from './components/furnitures/components/furniture-form/furniture-form.component';



@NgModule({
  declarations: [
    DashboardComponent,
    CategoryComponent,
    FurnitureTableComponent,
    MaterialTypeComponent,
    MaterialComponent,
    MaterialFormComponent,
    MaterialTableComponent,
    FurnituresComponent,
    FurnitureDetailComponent,
    FurnitureFormComponent,
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(FURNITURES_ROUTES),
    NgxPaginationModule,
    ReactiveFormsModule,
    FormsModule
  ]
})
export class FurnituresModule { }
