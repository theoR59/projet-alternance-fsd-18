export class RawMaterialsBean {
  id: string = "";
  name: string = "";
  company: string = ""
  type: string = ""
}
