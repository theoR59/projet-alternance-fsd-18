import {CategoryFurnituresBean} from "./CategoryFurnitures.bean";
import {RawMaterialsBean} from "./RawMaterials.bean";

export class FurnituresBean {
  id: string = ""
  name: string = ""
  category: CategoryFurnituresBean = new CategoryFurnituresBean()
  material: RawMaterialsBean[] = []
  image = {
    _1200x1200: "",
    _400x400: ""

  }
}
