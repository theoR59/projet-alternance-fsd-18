export class CategoryFurnituresBean {
  id: string = "";
  name: string = ""
}
