import {Injectable} from '@angular/core';
import {BehaviorSubject, catchError, Observable, of, switchMap, tap} from "rxjs";
import {FurnituresBean} from "../beans/Furnitures.bean";
import {RawMaterialsBean} from "../beans/RawMaterials.bean";
import {CategoryFurnituresBean} from "../beans/CategoryFurnitures.bean";
import {HttpClient} from "@angular/common/http";
import {environment} from "../../../environments/environment";
import {Params} from "@angular/router";
import {NgxUiLoaderService} from "ngx-ui-loader";

@Injectable({
  providedIn: 'root'
})
export class FurnituresService {
  private readonly _listFurnituresBehaviorSubject: BehaviorSubject<FurnituresBean[]> = new BehaviorSubject<FurnituresBean[]>([])
  public listFurnitures : Observable<FurnituresBean[]> = this._listFurnituresBehaviorSubject.asObservable()
  private readonly _furnitureBehaviorSubject: BehaviorSubject<FurnituresBean> = new BehaviorSubject<FurnituresBean>(new FurnituresBean())
  public furniture: Observable<FurnituresBean> = this._furnitureBehaviorSubject.asObservable()
  private readonly _listRawMaterialsBehaviorSubject: BehaviorSubject<RawMaterialsBean[]> = new BehaviorSubject<RawMaterialsBean[]>([])
  public listRawMaterials: Observable<RawMaterialsBean[]> = this._listRawMaterialsBehaviorSubject.asObservable()
  private readonly _listCategoriesBehaviorSubject: BehaviorSubject<CategoryFurnituresBean[]> = new BehaviorSubject<CategoryFurnituresBean[]>([])
  public listCategories: Observable<CategoryFurnituresBean[]> = this._listCategoriesBehaviorSubject.asObservable()


  constructor(private http: HttpClient,private ngxService: NgxUiLoaderService) {
  }

  public getAllFurnitures(): Observable<FurnituresBean[]> {
    this.ngxService.start()
    return this.http.get(environment.URL_BACK + environment.URL_BACK_ALL_FURNITURES,{withCredentials:true})
      .pipe(
        switchMap((datas: any) => {
          const newListFurnitures: FurnituresBean[] = []
          datas.forEach((data: any) => {
            newListFurnitures.push(this.mapFurnitureWithData(data))
          })
          this._listFurnituresBehaviorSubject.next(newListFurnitures)
          return of(newListFurnitures)
        }),
        tap(()=>{
          this.ngxService.stop()
        }),
        catchError((err )=>{
          this.ngxService.stop()
          throw err
        })
      )
  }

  public getFurniture(id: string): Observable<FurnituresBean> {
    this.ngxService.start()
    return this.http.get(`${environment.URL_BACK}${environment.URL_BACK_FURNITURE}${id}`,{withCredentials:true})
      .pipe(
        switchMap((data: any) => {
          const furniture : FurnituresBean = this.mapFurnitureWithData(data)
          this._furnitureBehaviorSubject.next(furniture)
          return of(furniture)
        }),
        tap(()=>{
          this.ngxService.stop()
        }),
        catchError((err )=>{
          this.ngxService.stop()
          throw err
        })
      )
  }

  public getAllRawMaterial(): Observable<RawMaterialsBean[]> {
    this.ngxService.start()
    return this.http.get(environment.URL_BACK + environment.URL_BACK_ALL_RAW_MATERIALS,{withCredentials:true})
      .pipe(
        switchMap((datas: any) => {
          const list: RawMaterialsBean[] = []
          datas.forEach((data: any) => {
            list.push(this.mapRawMaterialWithData(data))
          })
          this._listRawMaterialsBehaviorSubject.next(list)
          return of(list)
        }),
        tap(()=>{
          this.ngxService.stop()
        }),
        catchError((err )=>{
          this.ngxService.stop()
          throw err
        })
      )
  }

  public getAllCategories(): Observable<CategoryFurnituresBean[]> {
    this.ngxService.start()
    return this.http.get(environment.URL_BACK + environment.URL_BACK_ALL_CATEGORY,{withCredentials:true})
      .pipe(
        switchMap((datas: any) => {
          const list: CategoryFurnituresBean[] = []
          datas.forEach((data: any) => {
            list.push(this.mapCategoryWithData(data))
          })
          this._listCategoriesBehaviorSubject.next(list)
          return of(list)
        }),
        tap(()=>{
          this.ngxService.stop()
        }),
        catchError((err )=>{
          this.ngxService.stop()
          throw err
        })
      )
  }

  public createFurniture(furniture: FurnituresBean) {
    this.ngxService.start()
    return this.http.post(environment.URL_BACK + environment.URL_BACK_CREATE_FURNITURE, furniture,{withCredentials:true})
      .pipe(
        tap(()=>{
          this.ngxService.stop()
        }),
        catchError((err )=>{
          this.ngxService.stop()
          throw err
        })
      )
  }

  public createMaterial(material:RawMaterialsBean){
    this.ngxService.start()
    return this.http.post(environment.URL_BACK+environment.URL_BACK_CREATE_MATERIAL,material,{withCredentials:true})
      .pipe(
        tap(()=>{
          this.ngxService.stop()
        }),
        catchError((err )=>{
          this.ngxService.stop()
          throw err
        })
      )
  }

  public deleteFurniture(furniture:FurnituresBean){
    this.ngxService.start()
    return this.http.delete(environment.URL_BACK+environment.URL_BACK_DELETE_FURNITURE+furniture.id,{withCredentials:true})
      .pipe(
        tap(()=>{
          this.ngxService.stop()
        }),
        catchError((err )=>{
          this.ngxService.stop()
          throw err
        })
      )
  }

  public deleteMaterial(material:RawMaterialsBean){
    this.ngxService.start()
    return this.http.delete(environment.URL_BACK+environment.URL_BACK_DELETE_MATERIAL+material.id,{withCredentials:true})
      .pipe(
        tap(()=>{
          this.ngxService.stop()
        }),
        catchError((err )=>{
          this.ngxService.stop()
          throw err
        })
      )
  }

  private mapCategoryWithData(data: any): CategoryFurnituresBean {
    const category: CategoryFurnituresBean = new CategoryFurnituresBean()
    category.id = data._id
    category.name = data.name
    return category
  }

  private mapRawMaterialWithData(data: any): RawMaterialsBean {
    const material: RawMaterialsBean = new RawMaterialsBean()
    material.id = data._id
    material.name = data.name
    material.type = data.type
    material.company = data.company
    return material
  }

  private mapFurnitureWithData(data: any): FurnituresBean {
    const furniture: FurnituresBean = new FurnituresBean()
    furniture.id = data._id
    furniture.name = data.name
    furniture.category.id = data.category._id
    furniture.category.name = data.category.name
    furniture.material = data.material.map((material:any)=>{
      return {
        id : material._id,
        name: material.name,
        type : material.type,
        company : material.company,
      }
    })
    furniture.image._1200x1200 = data.image._1200x1200
    furniture.image._400x400 = data.image._400x400
    return furniture
  }


}
