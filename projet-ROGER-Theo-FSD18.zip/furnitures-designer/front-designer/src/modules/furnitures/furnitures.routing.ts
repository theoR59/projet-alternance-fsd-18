import {Routes} from "@angular/router";
import {AuthGuard} from "../authentification/guard/auth.guard";
import {DataUserGuard} from "../authentification/guard/data-user.guard";
import {DashboardComponent} from "./components/dashboard/dashboard.component";
import {MaterialComponent} from "./components/material/material.component";
import {FurnituresComponent} from "./components/furnitures/furnitures.component";
import {MaterialFormComponent} from "./components/material/components/material-form/material-form.component";
import {FurnitureFormComponent} from "./components/furnitures/components/furniture-form/furniture-form.component";
import {FurnitureDetailComponent} from "./components/furnitures/components/furniture-detail/furniture-detail.component";

export const FURNITURES_ROUTES: Routes = [
  {path: "", canActivate:[DataUserGuard,AuthGuard], component: DashboardComponent},
  {path:"furnitures",canActivate:[DataUserGuard,AuthGuard],component:FurnituresComponent},
  {path :"materials",canActivate:[DataUserGuard,AuthGuard],component:MaterialComponent},
  {path:"furnitures/:id",canActivate:[DataUserGuard,AuthGuard],component:FurnitureDetailComponent},
  {path:"create-furniture",canActivate:[DataUserGuard,AuthGuard],component:FurnitureFormComponent},
  {path:"create-material",canActivate:[DataUserGuard,AuthGuard],component:MaterialFormComponent}
]
