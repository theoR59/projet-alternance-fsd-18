import {Injectable} from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {BehaviorSubject, catchError, Observable, of, switchMap, tap} from "rxjs";
import {environment} from "../../../environments/environment";
import {UserBean} from "../beans/user.bean";
import {Router} from "@angular/router";
import {NgxUiLoaderService} from "ngx-ui-loader";

@Injectable({
  providedIn: 'root'
})
export class AuthentificationService {
  private readonly _userBehaviorSubject: BehaviorSubject<UserBean> = new BehaviorSubject<UserBean>(new UserBean())
  public user: Observable<UserBean> = this._userBehaviorSubject.asObservable()

  constructor(private http: HttpClient, private router: Router, private ngxService: NgxUiLoaderService) {
  }

  public login(credentials: UserBean): Observable<UserBean> {
    this.ngxService.start()
    return this.http.post(environment.URL_BACK + environment.URL_BACK_LOGIN, credentials, {withCredentials: true})
      .pipe(
        switchMap((data: any) => {
          const user = this.mapUserData(data)
          this._userBehaviorSubject.next(user)
          return of(user)
        }),
        tap(() => {
          this.ngxService.stop()
        }),
        catchError((err) => {
          this.ngxService.stop()
          throw err
        })
      )
  }

  public logout() {
    this.ngxService.start()
    return this.http.delete(environment.URL_BACK + environment.URL_BACK_LOGOUT, {withCredentials: true})
      .pipe(
        tap(() => {
          this._userBehaviorSubject.next(new UserBean())
          return this.router.navigateByUrl(environment.URL_FRONT_LOGIN)
        }),
        tap(() => {
          this.ngxService.stop()
        }),
        catchError((err) => {
          this.ngxService.stop()
          throw err
        })
      )
  }

  public fetchCurrentUser(): Observable<UserBean> {
    this.ngxService.start()
    return this.http.get(environment.URL_BACK + environment.URL_BACK_CURRENT, {withCredentials: true})
      .pipe(
        switchMap((data: any) => {
          if (data) {
            const user = this.mapUserData(data)
            this._userBehaviorSubject.next(user)
            return of(user)
          } else {
            return of(new UserBean())
          }
        }),
        tap(() => {
          this.ngxService.stop()
        }),
        catchError((err) => {
          this.ngxService.stop()
          throw err
        })
      )
  }

  public isUserConnected(): boolean {
    return !!this._userBehaviorSubject.value.id;
  }

  private mapUserData(data: any): UserBean {
    const user = new UserBean()
    user.id = data._id
    user.email = data.email
    user.role = data.role
    return user
  }
}
