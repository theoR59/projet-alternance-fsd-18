import {Injectable} from '@angular/core';
import {CanActivate, Router} from '@angular/router';
import {AuthentificationService} from "../services/authentification.service";
import {environment} from "../../../environments/environment";
import {Subscription} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  private isConnected: boolean = false


  constructor(private auth: AuthentificationService, private router: Router) {
  }

  canActivate(): boolean {
    this.isConnected = false
    if (this.auth.isUserConnected()) {
      this.isConnected = true
    }
    if (!this.isConnected) {
      this.router.navigateByUrl(environment.URL_FRONT_LOGIN)
    }
    return this.isConnected
  }
}
