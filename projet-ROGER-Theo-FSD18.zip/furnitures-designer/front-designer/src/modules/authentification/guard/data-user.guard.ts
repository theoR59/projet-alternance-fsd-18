import {Injectable} from '@angular/core';
import {CanActivate} from '@angular/router';
import {AuthentificationService} from "../services/authentification.service";


@Injectable({
  providedIn: 'root'
})
export class DataUserGuard implements CanActivate {
  constructor(private auth: AuthentificationService) {
  }

  canActivate(): true {
    if (!this.auth.isUserConnected()){
      this.auth.fetchCurrentUser().subscribe()
    }
    return true
  }
}
