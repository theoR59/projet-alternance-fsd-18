import {Routes} from "@angular/router";
import {LoginComponent} from "./components/login/login.component";
import {DataUserGuard} from "./guard/data-user.guard";


export const AUTH_ROUTES: Routes = [
  {path: "login",canActivate:[DataUserGuard], component: LoginComponent}
]
