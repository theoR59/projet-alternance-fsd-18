export class UserBean {
  id: string = ""
  email: string = "";
  password: string = "";
  role: string = ""
}
