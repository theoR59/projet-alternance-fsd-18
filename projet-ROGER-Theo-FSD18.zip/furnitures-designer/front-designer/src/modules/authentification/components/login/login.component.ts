import {Component, OnDestroy, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {UserBean} from "../../beans/user.bean";
import {AuthentificationService} from "../../services/authentification.service";
import {Router} from "@angular/router";
import {environment} from "../../../../environments/environment";
import {Subscription} from "rxjs";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {

  public loginForm!: FormGroup
  public showErrorMessage: boolean = false
  public showErrorEmail: boolean = false
  public showErrorPassword: boolean = false
  public errorMessage: string = ""
  public errorEmail: string = ""
  public errorPassword: string = ""
  public isConnected:boolean = false
  public user : UserBean = new UserBean()

  private subscribeOnUser?: Subscription

  private readonly message = {
    EMAIL_NOT_VALID: "L'email n'est pas valide",
    EMAIL_REQUIRED: "L'email obligatoire",
    PASSWORD_REQUIRED: "Mot de passe obligatoire",
    ERROR_LOGIN : "Mauvais email ou mot de passe"
  }

  constructor(private formBuilder: FormBuilder,private authServices : AuthentificationService, private router: Router) {
  }

  ngOnInit(): void {
    this.initForm()
    this.subscriptionOnUser()
  }

  ngOnDestroy() {
    this.subscribeOnUser?.unsubscribe()
  }

  private initForm():void {
    this.loginForm = this.formBuilder.group({
      email: ["", [Validators.email, Validators.required]],
      password: ["", Validators.required]
    })
  }

  private subscriptionOnUser() {
    this.subscribeOnUser = this.authServices.user.subscribe({
      next: (user) => {
        this.user = user
        this.isConnected = this.authServices.isUserConnected()
      }
    })
  }

  public submitLogin():void {
    this.resetErrorMessage()
    this.showErrorMessage = false
    if (this.loginForm.valid) {
      this.authServices.login(this.loginForm.getRawValue()).subscribe(
        (user:UserBean)=>{
          this.router.navigateByUrl(environment.URL_FRONT_DASHBOARD)
        },()=>{
          this.showErrorMessage = true
          this.errorMessage = this.message.ERROR_LOGIN
        }
      )
    } else {
      this.populateErrorMessage()
    }
  }

  private populateErrorMessage():void {
    this.setEmailError()
    this.setPasswordError()
  }

  private resetErrorMessage():void {
    this.showErrorEmail = false
    this.showErrorPassword = false
    this.errorEmail = ""
    this.errorMessage = ""
    this.errorPassword = ""
  }

  private setEmailError():void {
    this.showErrorEmail = true
    this.errorEmail = this.loginForm.get("email")?.hasError("email") ? this.message.EMAIL_NOT_VALID : this.loginForm.get("email")?.hasError("required") ? this.message.EMAIL_REQUIRED : ""
  }

  private setPasswordError():void {
    this.showErrorPassword = true
    this.errorPassword = this.loginForm.get("password")?.hasError("required") ? this.message.PASSWORD_REQUIRED : ""
  }

}
