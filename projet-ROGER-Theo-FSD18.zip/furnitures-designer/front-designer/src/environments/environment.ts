export const environment = {
  production: false,
  /*URL BACK*/
  URL_BACK: "http://localhost:3000",
  // URL_BACK:"https://back-designer.loca.lt",
  URL_BACK_LOGIN: "/api/login",
  URL_BACK_LOGOUT: "/api/logout",
  URL_BACK_CURRENT: "/api/current",
  URL_BACK_ALL_FURNITURES: "/api/furniture/all-furnitures",
  URL_BACK_FURNITURE:"/api/furniture/",
  URL_BACK_ALL_RAW_MATERIALS:"/api/furniture/raw-material",
  URL_BACK_ALL_CATEGORY:"/api/furniture/category-furniture",
  URL_BACK_CREATE_FURNITURE:"/api/furniture/create",
  URL_BACK_DELETE_FURNITURE:"/api/furniture/delete/",
  URL_BACK_DELETE_MATERIAL:"/api/furniture/delete-raw-material/",
  URL_BACK_CREATE_MATERIAL:"/api/furniture/create-raw-material",
  URL_BACK_UPDATE_IMAGE:"/api/furniture/new-image",


  /* URL FRONT */
  URL_FRONT_LOGIN: "/auth/login",
  URL_FRONT_DASHBOARD: "/dashboard",
  URL_FRONT_FURNITURE_DETAIL:"/dashboard/furnitures/",
  URL_FRONT_FURNITURE_LIST:"/dashboard/furnitures",
  URL_FRONT_MATERIAL_LIST:"/dashboard/materials"
};

